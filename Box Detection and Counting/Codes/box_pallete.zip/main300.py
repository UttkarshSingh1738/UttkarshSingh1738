import os
import numpy as np
from pprint import pprint
from cv2 import cv2
from math import ceil
from datetime import datetime
from detect_box_yolo import detect_box
import time
import collections
from statistics import mean

roiUPPER = 250 # upper ROI line
roiLOWER = 280  # lower ROI line

verti_roiLeft = 600
verti_roiRight = 1050

fixed_count = 3000   # the total boxes count will reset to zero after these no. of boxes gets counted


def is_dir(path):
    if not os.path.isdir(path):
        os.mkdir(path)
        print('Creating {}...'.format(path))


def draw_roi(frame, boundaries, rois, color_towel, color_pallete, color_person):
    global bbox_message

    # creating green and blue roi lines

    cv2.line(frame, (600, boundaries[0][1]), (1050, boundaries[0][1]), (0, 255, 0), 2)  # green roi
    cv2.line(frame, (600, boundaries[1][1]), (1050, boundaries[1][1]), (0, 255,0), 2)  # blue roi

    # cv2.line(frame, (verti_roiLeft, 0), (verti_roiLeft, 2000), (0, 0, 255), 2)  # blue roi
    # cv2.line(frame, (verti_roiRight, 0), (verti_roiRight, 2000), (0, 0, 255), 2)  # blue roi

    for roi in rois:

        # creating the centroid
        center = (int((roi[0] + roi[2]) / 2), int((roi[1] + roi[3]) / 2))
        cv2.circle(frame, center, 2, (0, 0, 255), 1)

        if roi[4] == 0:  # Box
            cv2.rectangle(frame, (roi[0] + 30, roi[1] + 30), (roi[2] - 30, roi[3] - 30), color_towel, thickness=2)
            bbox_message = 'box'
        elif roi[4] == 1:  # Pallet
            cv2.rectangle(frame, (roi[0], roi[1]), (roi[2], roi[3]), color_pallete, thickness=2)
            bbox_message = 'pallete'

        cv2.putText(frame, bbox_message, (roi[0] +30 , np.float32(roi[1] - 2)), cv2.FONT_HERSHEY_SIMPLEX,
                    0.5, (0, 0, 0), 1, lineType=cv2.LINE_AA)


def draw_lines(frame, coordinates, draw_buffer):
    color_left = (255, 0, 0)
    color_center = (0, 255, 0)
    color_right = (0, 0, 255)

    for i, coordinate in enumerate(coordinates):
        if i <= 1:
            cv2.line(frame, (coordinate[0], coordinate[1]), (coordinate[0], coordinate[2]), color_center, thickness=1)
            if draw_buffer:
                cv2.line(frame, (coordinate[0] - coordinate[3], coordinate[1]),
                         (coordinate[0] - coordinate[3], coordinate[2]), color_left, thickness=1)
                cv2.line(frame, (coordinate[0] + coordinate[3], coordinate[1]),
                         (coordinate[0] + coordinate[3], coordinate[2]), color_right, thickness=1)

    # cv2.line(frame, (coordinates[2][0],coordinates[2][1]),(242,coordinates[2][1]), color_right, thickness=1)


def make_vid(output_path, filename, fps=30):
    image_list = []
    image_path_list = os.listdir(output_path)
    image_path_list = sorted(image_path_list, key=lambda x: int(x[:len(x) - 4]))

    for image in image_path_list:
        img = cv2.imread(os.path.join(output_path, image))
        h, w, _ = img.shape
        size = (w, h)
        image_list.append(img)

    video = cv2.VideoWriter(filename, cv2.VideoWriter_fourcc(*'DIVX'), fps, size)

    for i in range(len(image_list)):
        video.write(image_list[i])

    video.release()
    print('Video Saved')


def check_position(rois, boundaries):
    in_upper = in_lower = False
    for roi in rois:
        if roi[4] == 0 and roi[0] < boundaries[0][0] and roi[1] < boundaries[2][1]:
            # print('in_upper check')
            in_upper = True
        if roi[4] == 0 and roi[0] < boundaries[0][0] and roi[1] > boundaries[2][1]:
            # print('in_lower check')
            in_lower = True
    return in_upper, in_lower


def analyse(rois, centre_corr, dir_corr, total_boxes, countarray, finalarray, finalarray2, final_boxes, fpers, counter):
    # rois = [[xmin, ymin, xmax, ymax, class_id]]

    analysis = {}
    global roiUPPER, roiLOWER, fixed_count, verti_roiRight, verti_roiRight
    ele = []  # appending the centroid coordinates
    roi_boxes = collections.deque(maxlen=6)  # appending counted boxes detected inside roi
    pallete = 0  # detected pallete
    direction = " "  # detected direction
    first = 0
    last = 0
    current_box = 0  # total boxes detected in one frame
    roiboxes_count = 0  # counting detected box inside roi
    counttext = " "           # text will generate when given number of boxes gets counted

    for roi in rois:

        # creating the centroid
        center = (int((roi[0] + roi[2]) / 2), int((roi[1] + roi[3]) / 2))

        # if centroid is inside the roi region
        if roiUPPER < center[1] < roiLOWER and verti_roiLeft < center[0] < verti_roiRight and roi[4] == 0:
            # counting the boxes inside the roi and appending them in list
            roiboxes_count = roiboxes_count + 1
            roi_boxes.append(roiboxes_count)
            # print(roi_boxes)
            # appending the centre coordinates inside the list
            ele.append(center[1])
            # if length of list is equal to max number of boxes passed
            if len(ele) == final_boxes:
                # print("ele :", ele)
                centre_corr.append(mean(ele))
        if roi[4] == 0:
            current_box = current_box + 1
        if roi[4] == 1:
            pallete = pallete + 1

    try:
        countarray.append((max(roi_boxes)))
        # finalarray.append(max(countarray))
        # finalarray2.append(max(finalarray))
        # final_boxes = max(finalarray2)
        final_boxes = max(countarray)

        first = centre_corr[-2]
        last = centre_corr[-1]

    except:
        pass

    diff = first - last

    print("diff",diff)

    if (diff > 0 and diff != 1):
        dir_corr.append("Upwards")

    elif (diff < 0 and diff != -1):
        dir_corr.append("Downwards")

    upCount = dir_corr.count("Upwards")
    downCount = dir_corr.count("Downwards")

    if upCount > downCount:
        direction = "Upwards"
    elif upCount < downCount:
        direction = "Downwards"
    elif upCount == downCount:
        pass

    try:
        if diff == 0 and dir_corr[-1] == "Downwards":
            total_boxes = total_boxes + 0

        elif diff == 0 and dir_corr[-1] == "Upwards":
            total_boxes = total_boxes + 0

        elif diff == -1 or diff == 1 and dir_corr[-1] == "Downwards" and direction == "Upwards":
            total_boxes = total_boxes + 0

        elif diff == 1 or diff == -1 and dir_corr[-1] == "Upwards" and direction == "Downwards":
            total_boxes = total_boxes + 0

        elif direction == "Upwards" and dir_corr[-1] == "Downwards":
            total_boxes = total_boxes + final_boxes

        elif direction == "Downwards" and dir_corr[-1] == "Upwards":
            total_boxes = total_boxes - final_boxes

    except:
        pass

    # if total boxes counted were 30 then the counter will get reset to 0
    if total_boxes > fixed_count:
        total_boxes = 0
        counttext = str(fixed_count) + "boxes Passed"

    analysis["Total_boxes_Count"] = total_boxes
    analysis["palletes"] = pallete
    analysis['Direction'] = direction
    analysis['FPS'] = fpers
    analysis['boxes_Detected'] = current_box
    analysis['boxes_Inside_ROI'] = roiboxes_count
    analysis["boxes_Counter"] = counttext
    analysis["Frame_no."] = counter

    return analysis, rois, centre_corr, dir_corr, total_boxes, countarray, finalarray, finalarray2, final_boxes, fpers, counter

def increment(y, flag):
    if flag == 'data':
        y += 30
    elif flag == 'line':
        y += 40
    return y


def write_analysis(frame, counter, analysis):
    line = '*' * 50
    font = cv2.FONT_HERSHEY_SIMPLEX
    font_scale_heading = 1
    font_scale = 0.7
    font_scale_line = 0.5
    font_color = (0, 0, 0)
    font_thickness = 2
    start_x = 1280
    start_y = 100

    # Realtime -> Being Made, Being Filled and Unattended
    cv2.putText(frame, 'Current Stats:', (start_x, start_y), font, font_scale_heading, font_color, font_thickness)
    start_y = increment(start_y, 'data')

    cv2.putText(frame, 'Boxes Detected: {}'.format(analysis['boxes_Detected']), (start_x, start_y), font,
                font_scale, font_color, font_thickness)
    start_y = increment(start_y, 'data')

    cv2.putText(frame, 'Pallet Detected: {}'.format(analysis['palletes']), (start_x, start_y), font,
                font_scale, font_color, font_thickness)
    start_y = increment(start_y, 'data')
    # cv2.putText(frame, 'Direction: {}'.format(analysis['Direction']), (start_x, start_y), font, font_scale, font_color,
    #             font_thickness)
    # start_y = increment(start_y, 'data')
    # cv2.putText(frame, 'boxes Detected(ROI): {}'.format(analysis['boxes_Inside_ROI']), (start_x, start_y), font,
    #             font_scale,
    #             font_color, font_thickness)
    # start_y = increment(start_y, 'data')
    # cv2.putText(frame, 'Frames Per Sec(FPS): {}'.format(analysis['FPS']), (start_x, start_y), font, font_scale,
    #             font_color, font_thickness)
    # start_y = increment(start_y, 'data')

    cv2.putText(frame, line, (start_x, start_y), font, font_scale_line, font_color, font_thickness)
    start_y = increment(start_y, 'line')

    # Total Values -> Total Created, Total Filled
    cv2.putText(frame, 'Production Summary:', (start_x, start_y), font, font_scale_heading, font_color, font_thickness)
    start_y = increment(start_y, 'data')

    cv2.putText(frame, 'Total Counted Boxes: {}'.format(analysis['Total_boxes_Count']), (start_x, start_y), font,
                font_scale,
                font_color, font_thickness)
    start_y = increment(start_y, 'data')
    # cv2.putText(frame, 'Frame: {}'.format(analysis['Frame_no.']), (start_x, start_y), font,
    #             font_scale,
    #             font_color, font_thickness)


def add_area(frame, logo):
    # image.shape = (352,640,3)
    # right side area (horizontal stack)
    black_area = np.zeros([720, 355, 3], dtype=np.uint8)
    black_area.fill(160)
    frame = np.concatenate((frame, black_area), axis=1)
    # top area (vertical stack)
    # black_area = np.zeros([50,910,3], dtype=np.uint8)
    # black_area.fill(175)
    # frame = np.concatenate((black_area, frame), axis=0)
    frame[0:logo.shape[0], frame.shape[1] - logo.shape[1]:frame.shape[1]] = logo
    return frame


def process_lines(data_path, filename, out_folder, out_filename, logo_path, boundaries, draw_person=False,
                  draw_division=False, draw_buffer=False):
    # color = (B,G,R)

    color_towel = (233, 39, 194)
    color_pallete = (185, 95, 63)
    color_person = (61, 255, 87)
    counter = 1

    fpers = 0  # counting FPS
    centre_corr = collections.deque(maxlen=3)  # center coordinates of boxes
    dir_corr = collections.deque(maxlen=3)  # direction coordinates
    total_boxes = 0 # Total boxes count
    countarray = collections.deque(maxlen=5)
    finalarray = collections.deque(maxlen=7)
    finalarray2 = collections.deque(maxlen=5)
    final_boxes = 0  # max number of towel

    logo = cv2.imread(logo_path)

    cap = cv2.VideoCapture(os.path.join(data_path, filename))

    while cap.isOpened():
        ret, frame = cap.read()

        # uncomment to crop the video frames

        # try:
        #     frame = frame[100:600, 150:950]    # follow this format [ymin : ymax, xmin : xmax]
        # except:
        #     print("Video has ended or failed, try a different video format!")

        start_time = time.time()

        if ret:
            if counter % 1 == 0:
                rois = detect_box(frame, 0.6)
                analysis, rois, centre_corr, dir_corr, total_boxes, countarray, finalarray, finalarray2, final_boxes, fpers, counter = analyse(
                    rois,
                    centre_corr, dir_corr, total_boxes, countarray, finalarray, finalarray2, final_boxes, fpers, counter)

                if draw_person:
                    draw_roi(frame, boundaries, rois, color_towel, color_pallete, color_person)
                if draw_division:
                    draw_lines(frame, boundaries, draw_buffer)

                frame = add_area(frame, logo)              # comment this line while using cropping
                write_analysis(frame, counter, analysis)
                print('Frame no: {}'.format(counter))
                cv2.imwrite(os.path.join(out_folder, str(counter) + '.jpg'), frame)
        else:
            cap.release()

        counter += 1

        if (time.time() - start_time) != 0:
            fpers = round(1.0 / (time.time() - start_time), 2)
        else:
            fpers = 0
        print("FPS :", fpers)
    # make_vid(out_folder,out_filename,fps=25)
    print('Done!')


if __name__ == "__main__":
    # logo_path = os.path.join('logos','logo.jpg')
    logo_path = "logo_new2.jpg"
    data_path = os.path.join('video_data')

    processed_frames_path = 'out'
    is_dir(processed_frames_path)

    result_video_path = 'result_vid'
    is_dir(result_video_path)

    locations = os.listdir(data_path)
    print(locations)
    for location in locations:
        # video_files = os.listdir(os.path.join(data_path,location))
        video_files = ["video.mp4"]
        print(video_files)
        for video_file in video_files:
            out_filename = os.path.join(result_video_path, 'result_' + location + '_' + video_file)

            # out_folder = os.path.join(processed_frames_path,'out_'+location+'_'+video_file.split('.')[0])
            out_folder = "out/box"
            is_dir(out_folder)

            # boundaries = [[x1,y1,y2,buffer]]
            # image.shape = (352,640,3)
            # boundaries[3] = [xmin,ymin+ymax/2,buffer] -> used for vertical workstations -> box creating stations
            boundaries = [[1920, roiUPPER, roiUPPER, 0], [1920, roiLOWER, roiLOWER, 0]]

            start = datetime.now()
            process_lines("video_data", video_file, out_folder, out_filename, logo_path, boundaries, draw_person=True,
                          draw_division=True)
            make_vid(out_folder, out_filename, fps=25)
            stop = datetime.now()
            print('Time Taken: {}'.format(stop - start))
